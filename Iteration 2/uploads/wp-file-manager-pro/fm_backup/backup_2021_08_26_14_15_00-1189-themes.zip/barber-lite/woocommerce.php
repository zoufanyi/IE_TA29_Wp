<?php get_header(); ?>
<div class="container">
<div id="TabNav-BL">
     <div class="SiteContent-BL fullwidth">  
			<?php woocommerce_content(); ?>
    </div><!-- SiteContent-BL-->   
</div><!-- #TabNav-BL --> 
</div><!-- .container -->     
<?php get_footer(); ?>