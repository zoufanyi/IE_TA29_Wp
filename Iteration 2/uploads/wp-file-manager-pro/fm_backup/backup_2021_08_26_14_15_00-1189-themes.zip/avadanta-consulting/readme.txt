=== Avadanta Consulting ===
Contributors: Avadantathemes
Requires at least: 5.0
Tested up to: 5.8
Requires PHP: 5.6
Stable tag: 1.0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags: one-column, two-columns, four-columns, right-sidebar, flexible-header, custom-background, custom-header, custom-menu, editor-style, featured-images, footer-widgets, rtl-language-support, translation-ready, full-width-template, custom-logo, blog, e-commerce, post-formats, theme-options, threaded-comments,  portfolio

Avadanta Consulting WordPress Free theme under GPL V2 


== Description ==

 Consulting based wp theme. Avadanta consulting high quality creative child wordpress theme. fully customizable child theme of avadanata. Perfect for business corporate. pre-made designed Homepage with 7 inner sections Featured Slider, teams, testimonials, portfolio, services, about sections,  Hero Content, call to action you can easily customize them. You can easily drag and drop the section position. Theme has dark header menu layout with top info bar with social media icons. The theme suitable for saas application website, architecture, interior design, corporate, agency, business, consulting, shop ecommerce, marketing, gym, blog, travel agency, construction,law firm, spa salons, industries, Beauty,  furniture, home decor, photography, insurance, app landing page, it solutions, decoration,  and many other websites compatible.You can change everything like Un limited color options, typography fonts, size etc. You can choose your own layout for your page with sidebar or without sidebar or full page content. You can customize navigation bar as you want like background color and menu color with sticky menu option.HIde show post meta and title for post. Unlimited  services icons. Translation ready theme. Support any type widget on footer and sidebar. You can change the footer widget column layout. Avadanta Consulting is a Pixel perfect and high defination all media screen sizes. Avadanta Theme woocommerce plugin supports you to create an online store with this theme. SEO Friendly and fast loading wordpress theme. Compatible with elementor page builder, gutenberg and so many popular plugins nicely works with avadanta theme. For more theme information, check out Theme demo here at https://www.avadantathemes.com/demo/avadanta-consulting/ and theme instructions here at https://www.avadantathemes.com/documentation/avadanta-free-theme/

Set Homepage Setup:-

1. Go to Dashboard >> Pages >> Add New, Create a new page and name it as "Home" then select the template "Avadanta Home Page" and publish it.

2. Go to Dashboard >> Settings >> Reading, Select the option of Static Page, now select the page you Created As the Home page.


== Frequently Asked Questions ==

= Does this theme support any plugins? =

Avadanta supports for Woocomerce, Elementor page builder plugin ans Also Other Plugins Too.

= Can I modify Theme? =

Avadanta developed under th GPL terms so you can use it free and can modify or redistribute according to your needs. 


== Changelog ==

= 1.0.1 =
* resolved file type escaping url issue

= 1.0 =
* Initial release


== Upgrade Notice ==

* No Upgrade In The Theme.



== Copyright ==

* Avadanta Consulting WordPress Theme, Copyright 2021
* Avadanta Consulting is distributed under the terms of the GNU GPL

== Resources ==


== Screenshot ==

Banner:
 https://pxhere.com/en/photo/1447641
 https://pxhere.com/en/photo/1442023
 

Header BG
 https://pxhere.com/en/photo/868163
 License: https://pxhere.com/en/license
 Images Used CC0 License