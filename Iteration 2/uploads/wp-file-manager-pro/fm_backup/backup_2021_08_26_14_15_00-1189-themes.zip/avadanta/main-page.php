<?php 
// Template Name: Avadanta Home Page
get_header();
	do_action( 'avata_avadanta_sections', false );
get_footer();
?>