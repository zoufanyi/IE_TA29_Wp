### 1.0.6 - July 14th, 2021

Changes:

- Completed changes mentioned in trac ticket https://themes.trac.wordpress.org/ticket/101968#comment:6


### 1.0.4 - July 6th, 2021

Changes:

- Updated stock photography license info in readme.txt


### 1.0.3 - July 5th, 2021

Changes:

- Completed changes mentioned in trac ticket https://themes.trac.wordpress.org/ticket/101829#comment:5


### 1.0.1 - July 2nd, 2021

Changes:

- Completed changes mentioned in trac ticket https://themes.trac.wordpress.org/ticket/101745#comment:3


### 1.0 - June 30th, 2021

Changes:

* INITIAL RELEASE *